<?php
/**
 * Plugin Name: Another Fake Plugin
 * Description: This is a another fake plugin
 * Version: 2.0.0
 * Author: StellarWP
 * Text Domain: another-fake-plugin
 * License: GPLv2 or later
 */
