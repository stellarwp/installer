<?php
/**
 * Plugin Name: Fake Plugin
 * Description: This is a fake plugin
 * Version: 1.0.0
 * Author: StellarWP
 * Text Domain: fake-plugin
 * License: GPLv2 or later
 */
